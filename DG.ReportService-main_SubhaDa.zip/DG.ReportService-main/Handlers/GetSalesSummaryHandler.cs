﻿using DG.ReportService.Models;
using DG.ReportService.Queries;
using MediatR;

namespace DG.ReportService.Handlers;

public class GetSalesSummaryHandler : IRequestHandler<GetSalesSummaryQuery, IEnumerable<SalesSummaryItem>>
{
    public readonly MockSalesSummary mockSalesSummary;

    public GetSalesSummaryHandler(MockSalesSummary mockSalesSummary) => this.mockSalesSummary = mockSalesSummary;


    public async Task<IEnumerable<SalesSummaryItem>> Handle(GetSalesSummaryQuery request, CancellationToken cancellationToken)
    {
        return mockSalesSummary.SalesSummaryItems;
    }
}
