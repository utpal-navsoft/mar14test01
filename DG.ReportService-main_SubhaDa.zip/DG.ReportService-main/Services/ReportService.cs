using Grpc.Core;
using DG.ReportService.Models;
using System.Threading.Tasks;
using MediatR;
using DG.ReportService.Queries;

namespace DG.ReportService.Services;

public class ReportService : Report.ReportBase
{
    private readonly IMediator mediator;

    public ReportService(IMediator mediator) => this.mediator = mediator;

    public override async Task GetSalesSummary(GetSalesSummaryRequest request, IServerStreamWriter<GetSalesSummaryResponse> responseStream, ServerCallContext context)
    {
        var salesSummaryReport = await mediator.Send(new GetSalesSummaryQuery());

        int serial = 1;
        foreach (Models.SalesSummaryItem summaryItem in salesSummaryReport)
        {
            await responseStream.WriteAsync(new GetSalesSummaryResponse()
            {
                SLNUMBER = serial++,
                SECTIONDESC = summaryItem.SECTION_DESC,
                LINEDESC = summaryItem.LINE_DESC,
                BEGINDATE = summaryItem.BEGIN_DATE,
                ENDDATE = summaryItem.END_DATE
            });
        };
    }
}
