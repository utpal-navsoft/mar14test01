namespace DG.ReportService.Models;

public class SalesSummaryItem
{
    public string FISCAL_YRPD { get; set; }
    public string LOCATION_ID { get; set; }
    public string SECTION_DESC { get; set; }
    public string EVENT_DATE { get; set; }
    public string LINE_DESC { get; set; }
    public string EXT_RETAIL_AMT { get; set; }
    public string TRANS_TYPE { get; set; }
    public string BATCH_ID { get; set; }
    public string INVOICE_NO { get; set; }
    public string TRAILER_NO { get; set; }
    public string DOC_NO { get; set; }
    public string BEGIN_DATE { get; set; }
    public string END_DATE { get; set; }
    public string SENDING_LOCATION { get; set; }
    public string RECEIVING_LOCATION { get; set; }
    public string FISCAL_WK { get; set; }
    public string BEG_INVENTORY_BAL { get; set; }
    public string END_INVENTORY_BAL { get; set; }
    public string TOTAL_CREDITS { get; set; }
    public string TOTAL_DEBITS { get; set; }
    public string ACKCDDT { get; set; }
}