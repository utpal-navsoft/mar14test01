using System;
using System.IO;

using System.Text.Json;
using System.Text.Json.Serialization;
using Newtonsoft.Json;

namespace DG.ReportService;

public class MockSalesSummary
{
    public List<Models.SalesSummaryItem> SalesSummaryItems;
    private readonly string jsonFilePath = System.IO.Directory.GetCurrentDirectory() + @"/Data/monthly_store_ta_Sales Summary.json";

    public MockSalesSummary()
    {
        Console.WriteLine(System.IO.Directory.GetCurrentDirectory());
        string text = string.Empty;
        if (File.Exists(jsonFilePath))
        {
            text = File.ReadAllText(jsonFilePath);
            Console.WriteLine("File found");
        }
        else
        {
            Console.WriteLine("No such file");
        }

        var items = Newtonsoft.Json.JsonConvert.DeserializeObject<List<Models.SalesSummaryItem>>(text);
        SalesSummaryItems = items;
    }
}