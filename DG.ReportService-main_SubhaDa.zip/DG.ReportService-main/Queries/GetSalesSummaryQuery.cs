﻿using DG.ReportService.Models;
using MediatR;

namespace DG.ReportService.Queries;

public record GetSalesSummaryQuery() : IRequest<IEnumerable<SalesSummaryItem>>;
