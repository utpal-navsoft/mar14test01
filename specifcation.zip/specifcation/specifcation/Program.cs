﻿

// Create an Invoice object
using specifcation.implementation;
using specifcation.Model;





var invoices = new List<Invoice>
{
    new Invoice { Id = 1, Number = "INV001", Total = 50.0m, IsPaid = false, Date = new DateTime(2023, 1, 5), FiscalPeriod = 1, StoreId = 100 },
    new Invoice { Id = 2, Number = "INV002", Total = 30.0m, IsPaid = true, Date = new DateTime(2023, 1, 10), FiscalPeriod = 2, StoreId = 101 },
    new Invoice { Id = 3, Number = "INV003", Total = 60.0m, IsPaid = false, Date = new DateTime(2023, 1, 12), FiscalPeriod = 3, StoreId = 102 },
    new Invoice { Id = 4, Number = "INV004", Total = 70.0m, IsPaid = false, Date = new DateTime(2023, 1, 13), FiscalPeriod = 4, StoreId = 103 },
    new Invoice { Id = 5, Number = "INV005", Total = 80.0m, IsPaid = false, Date = new DateTime(2023, 1, 14), FiscalPeriod = 5, StoreId = 104 },
    new Invoice { Id = 6, Number = "INV006", Total = 90.0m, IsPaid = false, Date = new DateTime(2023, 1, 15), FiscalPeriod = 6, StoreId = 105 }
};


var inventories = new List<Inventory>
{
    new Inventory { Id = 1, Name = "Widget A", Price = 10.0m, Quantity = 100, StoreId = 100, DateAdded = new DateTime(2023, 1, 1) },
    new Inventory { Id = 2, Name = "Widget B", Price = 15.0m, Quantity = 50, StoreId = 100, DateAdded = new DateTime(2023, 1, 5) },
    new Inventory { Id = 3, Name = "Widget C", Price = 20.0m, Quantity = 75, StoreId = 101, DateAdded = new DateTime(2023, 1, 10) },
    new Inventory { Id = 4, Name = "Widget D", Price = 25.0m, Quantity = 25, StoreId = 105, DateAdded = new DateTime(2023, 1, 15) },
    new Inventory { Id = 5, Name = "Widget E", Price = 30.0m, Quantity = 150, StoreId = 101, DateAdded = new DateTime(2023, 1, 20) }
};



//Multiple ways to handle Ors and andS

Console.WriteLine("Invoices with a fiscalPeriod of 1 OR 5 OR 6");

var fiscalPeriodSpec = new OrSpecification<Invoice>(
    new GenericSpecification<Invoice>(i => i.FiscalPeriod == 1),
    new GenericSpecification<Invoice>(i => i.FiscalPeriod == 5 || i.FiscalPeriod == 6));

Console.WriteLine("AND   storeid of 100 OR 101 or 105");

var storeIdSpec = new GenericSpecification<Invoice>(i => i.StoreId == 100 || i.StoreId == 101 || i.StoreId == 105);
Console.WriteLine("AND   dateRange of 1/1/23 - 1/15/23");

var dateRange = new DateRangeSpecification<Invoice>(i => i.Date, new DateTime(2023, 1, 1), new DateTime(2023, 1, 15));
Console.WriteLine("AND   invoice totsal <= 50.0");
var invoiceTotal = new NumberComparisonSpecification<Invoice>(i => i.Total, 50.0m, "<=");

var completeFilter = fiscalPeriodSpec.And(dateRange).And(invoiceTotal).And(storeIdSpec);


var filteredInvoices = invoices.Where(completeFilter.IsSatisfiedBy).ToList();


filteredInvoices.ForEach(Console.WriteLine);
Console.WriteLine("---------------------------");
Console.WriteLine("Show all inventory where quantity is between 10 and 90");


var qtySpec = new NumberRangeSpecification<Inventory>(i => i.Quantity, 10, 90);

Console.WriteLine("AND storeid is 100 or 101");
var storeIdSpec2 = new OrSpecification<Inventory>(
    new GenericSpecification<Inventory>(i => i.StoreId == 100),
    new GenericSpecification<Inventory>(i => i.StoreId == 101));

var filter = qtySpec.And(storeIdSpec2);
var filteredInventory = inventories.Where(filter.IsSatisfiedBy).ToList();


filteredInventory.ForEach(Console.WriteLine);
