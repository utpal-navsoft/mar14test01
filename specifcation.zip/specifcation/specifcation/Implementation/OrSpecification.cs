﻿using specifcation.interfaces;

namespace specifcation.implementation;

public class OrSpecification<T> : Specification<T>
{
    private readonly ISpecification<T> _specification1;
    private readonly ISpecification<T> _specification2;

    public OrSpecification(ISpecification<T> specification1, ISpecification<T> specification2)
    {
        _specification1 = specification1;
        _specification2 = specification2;
    }

    public override bool IsSatisfiedBy(T entity)
    {
        return _specification1.IsSatisfiedBy(entity) || _specification2.IsSatisfiedBy(entity);
    }
}
