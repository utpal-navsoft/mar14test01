﻿namespace specifcation.implementation;

public class NumberComparisonSpecification<T> : Specification<T> where T : class
{
    private readonly Func<T, decimal> _decimalAccessor;
    private readonly decimal _value;
    private readonly string _operator;

    public NumberComparisonSpecification(Func<T, decimal> decimalAccessor, decimal value, string @operator)
    {
        _decimalAccessor = decimalAccessor;
        _value = value;
        _operator = @operator;
    }

    public override bool IsSatisfiedBy(T entity)
    {
        var decimalValue = _decimalAccessor(entity);

        switch (_operator)
        {
            case ">":
                return decimalValue > _value;
            case ">=":
                return decimalValue >= _value;
            case "<":
                return decimalValue < _value;
            case "<=":
                return decimalValue <= _value;
            default:
                throw new ArgumentException($"Invalid operator: {_operator}", nameof(_operator));
        }
    }
}