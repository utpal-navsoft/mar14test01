﻿using specifcation.interfaces;

namespace specifcation.implementation;

public class DateRangeSpecification<T> : Specification<T> where T : class, IEntity
{
    private readonly Func<T, DateTime> _dateAccessor;
    private readonly DateTime _startDate;
    private readonly DateTime _endDate;

    public DateRangeSpecification(Func<T, DateTime> dateAccessor, DateTime startDate, DateTime endDate)
    {
        _dateAccessor = dateAccessor;
        _startDate = startDate;
        _endDate = endDate;
    }

    public override bool IsSatisfiedBy(T entity)
    {
        DateTime date = _dateAccessor(entity);
        return date >= _startDate && date <= _endDate;
    }
}