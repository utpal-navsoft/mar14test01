﻿namespace specifcation.implementation;

public class NumberRangeSpecification<T> : Specification<T> where T : class
{
    private readonly Func<T, decimal> _decimalAccessor;
    private readonly decimal _minValue;
    private readonly decimal _maxValue;

    public NumberRangeSpecification(Func<T, decimal> decimalAccessor, decimal minValue, decimal maxValue)
    {
        _decimalAccessor = decimalAccessor;
        _minValue = minValue;
        _maxValue = maxValue;
    }

    public override bool IsSatisfiedBy(T entity)
    {
        var decimalValue = _decimalAccessor(entity);
        return decimalValue >= _minValue && decimalValue <= _maxValue;
    }
}