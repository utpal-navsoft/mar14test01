﻿using System.Linq.Expressions;

namespace specifcation.implementation;

public class GenericSpecification<T> : Specification<T> where T : class
{
    private readonly Expression<Func<T, bool>> _expression;

    public GenericSpecification(Expression<Func<T, bool>> expression)
    {
        _expression = expression;
    }

    public override bool IsSatisfiedBy(T entity)
    {
        return _expression.Compile().Invoke(entity);
    }
}
