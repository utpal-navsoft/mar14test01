﻿namespace specifcation.interfaces;

public interface IEntity
{
    int Id { get; set; }
    int FiscalPeriod { get; set; }
    int StoreId { get; set; }
}