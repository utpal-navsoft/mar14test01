﻿using specifcation.interfaces;
using System.Text;

namespace specifcation.Model;

public abstract class Entity : IEntity
{
    public int Id { get; set; }
    public int FiscalPeriod { get; set; }
    public int StoreId { get; set; }

    public override string ToString()
    {
        var properties = GetType().GetProperties();
        var sb = new StringBuilder();
        sb.Append($"{GetType().Name} {{ {string.Join(", ", properties.Select(p => $"{p.Name}: {(p.PropertyType == typeof(DateTime) ? ((DateTime)p.GetValue(this)).ToString("d") : p.GetValue(this))}"))} }}");
        return sb.ToString();
    }

  


}