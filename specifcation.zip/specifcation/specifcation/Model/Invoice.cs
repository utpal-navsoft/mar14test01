﻿namespace specifcation.Model;

public class Invoice : Entity
{
    public string Number { get; set; }
    public decimal Total { get; set; }
    public bool IsPaid { get; set; }
    public DateTime Date { get; set; }
 
}

