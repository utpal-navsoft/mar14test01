﻿using TaSheet.Domain.Interfaces;

namespace TaSheet.Reporting.Infrastructure.Repository
{
    public class InMemoryRepository<T> : IRepository<T> where T : class, IEntity<string>
    {
        private readonly List<T> _entities;

        public InMemoryRepository()
        {
            _entities = new List<T>();
        }

        public async Task AddAsync(T entity)
        {
            _entities.Add(entity);
            await Task.CompletedTask;
        }

        public async Task DeleteAsync(string id)
        {
            var entity = await GetByIdAsync(id);
            if (entity != null)
            {
                _entities.Remove(entity);
            }
            await Task.CompletedTask;
        }

        public async Task<IEnumerable<T>> GetAllAsync()
        {
            return await Task.FromResult(_entities.AsEnumerable());
        }

        public async Task<T?> GetByIdAsync(string id)
        {
            return await Task.FromResult(_entities?.FirstOrDefault(e => e.Id == id));
        }

        public async Task UpdateAsync(T entity) => await Task.CompletedTask;
        

        public async Task<IEnumerable<T>> SearchAsync(ISpecification<T> specification)
        {
            var query = _entities.AsQueryable();

        
            if (specification.Criteria != null)
            {
                query = query.Where(specification.Criteria);
            }

            return await Task.FromResult(query.AsEnumerable());
        }



    }
}
