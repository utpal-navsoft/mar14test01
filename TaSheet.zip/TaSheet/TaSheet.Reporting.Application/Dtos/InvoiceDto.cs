﻿namespace TaSheet.Reporting.Application.Dtos;

public class InvoiceDto
{
    public string Id { get; set; }
    public int StoreNumber { get; set; }
    public string FiscalPeriod { get; set; } = default!;
    public DateTime CreatedDate { get; set; }
    public ICollection<InvoiceItemDto> Items { get; set; }
}