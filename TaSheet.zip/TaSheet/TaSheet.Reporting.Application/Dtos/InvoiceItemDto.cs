﻿namespace TaSheet.Reporting.Application.Dtos;

public class InvoiceItemDto
{
    public string Id { get; set; }
    public string Description { get; set; } = default!;
    public decimal Amount { get; set; }
}