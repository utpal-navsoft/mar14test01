﻿using AutoMapper;
using TaSheet.Domain.Models;
using TaSheet.Reporting.Application.Dtos;

namespace TaSheet.Reporting.Application.Mappers
{
    public class InvoiceProfile : Profile
    {
        public InvoiceProfile()
        {
            CreateMap<Invoice, InvoiceDto>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id.ToString()))
                .ForMember(dest => dest.StoreNumber, opt => opt.MapFrom(src => src.StoreNumber))
                .ForMember(dest => dest.FiscalPeriod, opt => opt.MapFrom(src => src.FiscalPeriod))
                .ForMember(dest => dest.Items, opt => opt.MapFrom(src => src.Items));

            CreateMap<InvoiceItem, InvoiceItem>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id.ToString()))
                .ForMember(dest => dest.Quantity, opt => opt.MapFrom(src => src.Quantity))
                .ForMember(dest => dest.Gtin, opt => opt.MapFrom(src => src.Gtin))
                .ForMember(dest => dest.RetailCost, opt => opt.MapFrom(src => src.RetailCost));
        }
    }
}
