﻿using MediatR;
using TaSheet.Domain.Models;

namespace TaSheet.Reporting.Application.Commands;

public class CreateInvoiceCommand : IRequest<string>
{
    public Invoice Invoice { get; set; } = default!;
}