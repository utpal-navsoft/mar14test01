﻿using MediatR;

namespace TaSheet.Reporting.Application.Commands;

public class DeleteInvoiceCommand : IRequest<Unit>
{
    public string Id { get; set; }

    public DeleteInvoiceCommand(string id)
    {
        Id = id;
    }
}
