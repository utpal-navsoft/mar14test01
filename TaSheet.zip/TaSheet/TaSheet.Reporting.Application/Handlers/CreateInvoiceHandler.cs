﻿using MediatR;
using TaSheet.Domain.Interfaces;
using TaSheet.Domain.Models;
using TaSheet.Reporting.Application.Commands;

namespace TaSheet.Reporting.Application.Handlers;

public class CreateInvoiceCommandHandler : IRequestHandler<CreateInvoiceCommand, string>
{
    private readonly IRepository<Invoice> _repository;

    public CreateInvoiceCommandHandler(IRepository<Invoice> repository)
    {
        _repository = repository;
    }

    public async Task<string> Handle(CreateInvoiceCommand request, CancellationToken cancellationToken)
    {
        await _repository.AddAsync(request.Invoice);
        return request.Invoice.Id;
    }
}
