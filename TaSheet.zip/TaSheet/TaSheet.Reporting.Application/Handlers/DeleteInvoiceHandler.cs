﻿using MediatR;
using TaSheet.Domain.Interfaces;
using TaSheet.Domain.Models;
using TaSheet.Reporting.Application.Commands;

namespace TaSheet.Reporting.Application.Handlers;
public class DeleteInvoiceHandler : IRequestHandler<DeleteInvoiceCommand, Unit>
{
    private readonly IRepository<Invoice> _repository;

    public DeleteInvoiceHandler(IRepository<Invoice> repository)
    {
        _repository = repository;
    }

    public async Task<Unit> Handle(DeleteInvoiceCommand request, CancellationToken cancellationToken)
    {
        await _repository.DeleteAsync(request.Id);
        return Unit.Value;
    }
}