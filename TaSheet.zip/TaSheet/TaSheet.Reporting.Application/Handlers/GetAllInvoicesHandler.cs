﻿using AutoMapper;
using MediatR;
using TaSheet.Domain.Interfaces;
using TaSheet.Domain.Models;
using TaSheet.Reporting.Application.Queries;

namespace TaSheet.Reporting.Application.Handlers
{
    public class GetAllInvoicesQueryHandler : IRequestHandler<GetAllInvoicesQuery, IEnumerable<Invoice>>
    {
        private readonly IRepository<Invoice> _repository;
        private readonly IMapper _mapper;

        public GetAllInvoicesQueryHandler(IRepository<Invoice> repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        public async Task<IEnumerable<Invoice>> Handle(GetAllInvoicesQuery request, CancellationToken cancellationToken)
        {
            var invoices = await _repository.GetAllAsync();
            return _mapper.Map<IEnumerable<Invoice>>(invoices);
        }
    
    }
}
