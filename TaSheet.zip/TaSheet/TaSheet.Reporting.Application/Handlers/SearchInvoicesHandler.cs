﻿using AutoMapper;
using MediatR;
using TaSheet.Domain.Interfaces;
using TaSheet.Domain.Models;
using TaSheet.Domain.Specifications;
using TaSheet.Reporting.Application.Queries;

namespace TaSheet.Reporting.Application.Handlers;


public class SearchInvoicesQueryHandler : IRequestHandler<SearchInvoicesQuery, IEnumerable<Invoice>>
{
    private readonly IRepository<Invoice> _repository;
    private readonly IMapper _mapper;

    public SearchInvoicesQueryHandler(IRepository<Invoice> repository, IMapper mapper)
    {
        _repository = repository;
        _mapper = mapper;
    }

    public async Task<IEnumerable<Invoice>> Handle(SearchInvoicesQuery request, CancellationToken cancellationToken)
    {
        var specification = new InvoicesByStoreAndPeriodSpecification(request.StoreId, request.FiscalPeriod);
        var invoices = await _repository.SearchAsync(specification);
        return _mapper.Map<IEnumerable<Invoice>>(invoices);
    }
}
