﻿using AutoMapper;
using MediatR;
using TaSheet.Domain.Interfaces;
using TaSheet.Domain.Models;
using TaSheet.Reporting.Application.Queries;

namespace TaSheet.Reporting.Application.Handlers;

public class GetInvoiceByIdHandler : IRequestHandler<GetInvoiceByIdQuery, Invoice>
{
    private readonly IRepository<Invoice> _repository;
    private readonly IMapper _mapper;

    public GetInvoiceByIdHandler(IRepository<Invoice> repository, IMapper mapper)
    {
        _repository = repository;
        _mapper = mapper;
    }

    public async Task<Invoice> Handle(GetInvoiceByIdQuery request, CancellationToken cancellationToken)
    {
        var invoice = await _repository.GetByIdAsync(request.Id);
        return _mapper.Map<Invoice>(invoice);
    }
}
