﻿namespace TaSheet.Reporting.Application.Exceptions;

public class NotFoundException : ApplicationException
{
    public NotFoundException(string entityName, object entityId): base($"{entityName} with id '{entityId}' was not found."){}

} 