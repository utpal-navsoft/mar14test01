﻿using MediatR;
using TaSheet.Domain.Models;

namespace TaSheet.Reporting.Application.Queries;

public class GetInvoiceByIdQuery : IRequest<Invoice>
{
    public GetInvoiceByIdQuery(string id)
    {
        Id = id;
    }

    public string Id { get; }
}