﻿using MediatR;
using TaSheet.Domain.Models;

namespace TaSheet.Reporting.Application.Queries;

public class GetAllInvoicesQuery : IRequest<IEnumerable<Invoice>> { }


 
