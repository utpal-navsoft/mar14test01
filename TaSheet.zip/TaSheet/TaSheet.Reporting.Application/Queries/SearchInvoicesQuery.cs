﻿using MediatR;
using TaSheet.Domain.Models;

namespace TaSheet.Reporting.Application.Queries;

public class SearchInvoicesQuery : IRequest<IEnumerable<Invoice>>
{
    public int StoreId { get; }
    public string FiscalPeriod { get; }

    public SearchInvoicesQuery(int storeId, string fiscalPeriod)
    {
        StoreId = storeId;
        FiscalPeriod = fiscalPeriod;
    }
}