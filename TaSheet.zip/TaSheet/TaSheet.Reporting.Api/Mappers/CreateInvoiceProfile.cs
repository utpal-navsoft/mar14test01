﻿using AutoMapper;
using Model = TaSheet.Domain.Models;
namespace TaSheet.Reporting.Api.Mappers
{
    public class CreateInvoiceProfile: Profile
    {
        public CreateInvoiceProfile()
        {
            CreateMap<CreateInvoiceRequest, Model.Invoice>()
                .ForMember(dest => dest.Id, opt => opt.Ignore())
                .ForMember(dest => dest.TimeStamp, opt => opt.MapFrom(src => DateTime.UtcNow));
        }
    }
}
