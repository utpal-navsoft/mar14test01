﻿using AutoMapper;
using Google.Protobuf.WellKnownTypes;
using Grpc.Core;
using MediatR;
using TaSheet.Reporting.Application.Commands;
using TaSheet.Reporting.Application.Dtos;
using TaSheet.Reporting.Application.Queries;

namespace TaSheet.Reporting.Api.Services
{
    public class Invoices : InvoiceService.InvoiceServiceBase
    {
        private readonly IMapper _mapper;
        private readonly IMediator _mediator;

        public Invoices(IMapper mapper, IMediator mediator)
        {
            _mapper = mapper;
            _mediator = mediator;
        }

        public override async Task<CreateInvoiceResponse> CreateInvoice(CreateInvoiceRequest request, ServerCallContext context)
        {
            var createInvoiceCommand = _mapper.Map<CreateInvoiceCommand>(request);
            var invoiceId = await _mediator.Send(createInvoiceCommand);

            return new CreateInvoiceResponse() { Id = invoiceId };

        }

        public override async Task<Invoice> GetInvoiceById(GetInvoiceByIdRequest request, ServerCallContext context)
        {
            var query = new GetInvoiceByIdQuery(request.Id);
            var invoice = await _mediator.Send(query);
            var invoiceDto = _mapper.Map<InvoiceDto>(invoice);
            var invoiceProto = _mapper.Map<Invoice>(invoiceDto);
            return invoiceProto;
        }

        public override async Task GetAllInvoices(GetAllInvoicesRequest request, IServerStreamWriter<Invoice> responseStream, ServerCallContext context)
        {
            var query = new GetAllInvoicesQuery();
            var invoices = await _mediator.Send(query);
            var invoiceDtos = invoices.Select(_mapper.Map<InvoiceDto>);
            foreach (var invoiceDto in invoiceDtos)
            {
                var invoice = _mapper.Map<Invoice>(invoiceDto);
                await responseStream.WriteAsync(invoice);
            }
        }

        public override async Task SearchInvoices(SearchInvoicesRequest request, IServerStreamWriter<Invoice> responseStream, ServerCallContext context)
        {
            var query = new SearchInvoicesQuery(request.StoreNumber, request.FiscalPeriod);
            var invoices = await _mediator.Send(query);
            var invoiceDtos = invoices.Select(_mapper.Map<InvoiceDto>);
            foreach (var invoiceDto in invoiceDtos)
            {
                var invoice = _mapper.Map<Invoice>(invoiceDto);
                await responseStream.WriteAsync(invoice);
            }
        }

        public override async Task<Empty> DeleteInvoice(DeleteInvoiceRequest request, ServerCallContext context)
        {
            var command = new DeleteInvoiceCommand(request.Id);
            await _mediator.Send(command);
            return new Empty();
        }
    }
}
