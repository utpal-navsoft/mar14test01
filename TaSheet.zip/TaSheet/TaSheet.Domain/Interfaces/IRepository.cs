﻿namespace TaSheet.Domain.Interfaces;

public interface IRepository<T> where T : class, IEntity<string>
{
    Task<IEnumerable<T>> GetAllAsync();
    Task<T?> GetByIdAsync(string id);
    Task AddAsync(T entity);
    Task UpdateAsync(T entity);
    Task DeleteAsync(string id);
    Task<IEnumerable<T>> SearchAsync(ISpecification<T> specification);
}
