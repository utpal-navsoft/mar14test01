﻿using System.Linq.Expressions;
using TaSheet.Domain.Interfaces;
using TaSheet.Domain.Models;

namespace TaSheet.Domain.Specifications
{
    public class InvoicesByStoreAndPeriodSpecification : ISpecification<Invoice>
    {

        public InvoicesByStoreAndPeriodSpecification(int storeId, string fiscalPeriod)
        {
            Criteria = i => i.StoreNumber == storeId && i.FiscalPeriod == fiscalPeriod;
            Includes = default!;
        }

        public Expression<Func<Invoice, bool>> Criteria { get; }
        public List<Expression<Func<Invoice, object>>> Includes { get; }

    }
}
