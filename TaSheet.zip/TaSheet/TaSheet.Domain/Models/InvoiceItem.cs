﻿using TaSheet.Domain.Interfaces;

namespace TaSheet.Domain.Models;

public class InvoiceItem : IEntity<string>
{
    public string Id { get; set; } = default!;
    public string InvoiceId { get; set; } = default!;
    public int VendorNumber { get; set; }
    public string InvoiceNumber { get; set; } = default!;
    public int LineNumber { get; set; }
    public int StoreNumber { get; set; }
    public string OriginalGtin { get; set; } = default!;
    public string Gtin { get; set; } = default!;
    public int Quantity { get; set; }
    public double VendorItemCost { get; set; }
    public double DgItemCost { get; set; }
    public double RetailCost { get; set; }
    public double ExtendedRetail { get; set; }
    public string Isbn { get; set; } = default!;
    public string Ipvndsty { get; set; } = default!;
    public string VxDpt { get; set; } = default!;
    public int QtyMultiplier { get; set; }
    public string UseVendorCost { get; set; } = default!;
    public string SplitFlag { get; set; } = default!;
    public string LineItemRevision { get; set; } = default!;

}
