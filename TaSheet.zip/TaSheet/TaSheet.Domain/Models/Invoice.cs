﻿using TaSheet.Domain.Interfaces;


namespace TaSheet.Domain.Models;
public class Invoice : IEntity<string>
{
    public string Id { get; set; } = default!;
    public int VendorNumber { get; set; }
    public string VendorReportedName { get; set; } = default!;
    public string ApInvoiceNumber { get; set; } = default!;
    public string VendorInvoiceNumber { get; set; } = default!;
    public int StoreNumber { get; set; }
    public string InvoiceType { get; set; } = default!;
    public string CreateUser { get; set; } = default!;
    public DateTime TimeStamp { get; set; }
    public string InvoiceSource { get; set; } = default!;
    public DateTime InvoiceDate { get; set; }
    public string FiscalPeriod { get; set; } = default!;
    public DateTime ShipDate { get; set; }
    public DateTime PostDate { get; set; }
    public string ShipVia { get; set; } = default!;
    public int TermsDays { get; set; }
    public double DiscountPct { get; set; }
    public double DiscountAmt { get; set; }
    public double AddlDiscount { get; set; }
    public DateTime DueDate { get; set; }
    public double InvoiceCost { get; set; }
    public double InvPrvCost { get; set; }
    public double RetailCost { get; set; }
    public double DgInvoiceCost { get; set; }
    public double AllowanceAuxFeeTotal { get; set; }
    public string InvoiceStatus { get; set; } = default!;
    public string TransferStatus { get; set; } = default!;
    public string ReleaseStatus { get; set; } = default!;
    public string ChgUserName { get; set; } = default!;
    public DateTime ChgTimeStamp { get; set; }
    public string QtyMultiplier { get; set; } = default!;
    public string DocumentNumber { get; set; } = default!;
    public string RevisionNumber { get; set; } = default!;
    public string PONumber { get; set; } = default!;
    public List<InvoiceItem> Items { get; set; } = default!;
}
